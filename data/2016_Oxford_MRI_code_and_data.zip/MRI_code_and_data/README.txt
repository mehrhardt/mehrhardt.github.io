%% Note on usage:
% In case you use this code for a scientific publication, please cite
% M. J. Ehrhardt and M. M. Betcke, “Multi-contrast mri reconstruction with 
% structure-guided total variation,” (to appear in) SIAM Journal on Imaging Sciences, 2016.

% This code has been developed for a 1.5h practical session for the
% 2016 European Summer School in Modelling, Analysis and Simulation Crime and Image Processing
% at the University of Oxford. Please feel free to reuse the code for any scientific or academic
% purposes.
