%% Note on usage:
% In case you use this code for a scientific publication, please cite
% M. J. Ehrhardt and M. M. Betcke, “Multi-contrast mri reconstruction with 
% structure-guided total variation,” (to appear in) SIAM Journal on Imaging Sciences, 2016.

% 2016-07-04 --------------------------------------------------------------
% Matthias J. Ehrhardt
% Department for Applied Mathematics and Theoretical Physics, University of Cambridge
% m.j.ehrhardt@damtp.cam.ac.uk, www.damtp.cam.ac.uk/user/me404
% -------------------------------------------------------------------------
% Copyright 2016 University of Cambridge
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

%% Getting started. This tutorial explains MRI data and how we reconstruct from it.
% You should go through it step by step. Either by executing individual lines
% (mark them and press F9) or by executing each cell.
% Cells that are marked with an asterisk (*) are optional and can be left
% out without interfering with the following code.

% To get started, initalize the paths 
clear all
init

%% Part I. Familarise yourself with MRI data
% First load some data
% load training_data/phantom/data_phantom.mat
load training_data/scan1/scan1_data.mat
% load test_data/scan2/scan2_data.mat

%% Step I.1*. Load and have a look at MRI data
% Visualize the data. NOTE: MRI data is complex valued!
d = data.sampling10;
figure(1);
subplot(311); plot(real(d.meas)); hold on; 
subplot(311); plot(imag(d.meas)); hold off;
legend('real part', 'imag part');
title('MRI data');

%% TASK*: 
% Familiarize yourself with the data by zooming into some interesting areas.

%% Step I.2*. Make sense of MRI data
% MRI data is related to the 2D Fourier transform.
% We have to know what are the frequencies that data points corresponds to.

% Display frequencies. The vector "freq" saves all the frequencies in x and 
% y direction for the data. This means, the n-th data point (d.meas(n)) is
% the data that corresponds to the frequencies d.freq(1,n) and d.freq(2,n).
figure(1)
subplot(323); plot(d.freq(1,:)); hold on;
subplot(323); plot(d.freq(2,:)); hold off;
legend('freq x', 'freq y');
title('frequencies for data');

%% TASK*:
% Can you imagine the trajectory how the data was sampled?

%% Step I.2.1*. We can also display the trajectory in form of "indices" of a 2D matrix 
% column by column
s_kspace = 256 * [1, 1];
ind = MRI_freq2ind(d.freq, s_kspace);
figure(1)
subplot(324); plot(ind);
title('indices for data');

%% Step I.3. The k-space
% Knowing the frequencies, we can transform this abstract data into
% "k-space", the native space of MRI data.
s_kspace = 256 * [1, 1];
ind = MRI_freq2ind(d.freq, s_kspace);
kspace_data = MRI_sample_index_backward(d.meas, ind, s_kspace);

% The kspace is a two dimensional representation of the data. Therefore we 
% can visualize it as an image.
figure(1)
subplot(325); imagesc(log(abs(kspace_data))); axis image; colorbar;
title('log abs kspace');

% As the data is complex we had to take absolute values to show it. To see
% its complex nature, here is the imaginary part.
figure(1)
subplot(326); imagesc(imag(kspace_data)); axis image; colorbar;
title('imag kspace');

%% TASK*: 
% You now got to know this data set. In MRI, there are lots of different 
% ways how to sample. Look at a few other samplings (e.g. data.sampling20). 
% What is different?
% You can also load a different data set (c.f. step 1) and look at that data.

%% Part II. MRI Reconstruction

%% Step II.1. Reconstruction without a prior
% In this section we reconstruct an image from MRI data without using any
% a priori knowledge about the solution (beside that the solution should be
% non-negative).

% Select a data set
% Load training_data/phantom/data_phantom.mat
load training_data/scan1/scan1_data.mat
% load test_data/scan2/scan2_data.mat
d = data.sampling1;

% Compute the k-space representation of the data set
ind = MRI_freq2ind(d.freq, s_kspace);
kspace_data = MRI_sample_index_backward(d.meas, ind, s_kspace);
% Show the data
figure(2)
subplot(221); imagesc(log(abs(kspace_data))); axis image; colorbar; title(sprintf('log abs kspace, %3.2f%% data', numel(d.meas)/numel(kspace_data)*100));

% Select the prox operator for the non-negativity constraint. This is the 
% orthogonal projection onto the nonnegative quadrant. The second output 
% variable "nan" is a dummy variable that is needed internally.
Prox_J = @(x, rho, p) deal( max(x,0), nan );

% Select the parameters of ADMM
nIter = 300;
rho = 1;
tol = 1e-4;
u_init = zeros(s_kspace);

% Create a function handle that applies this reconstruction
ADMM_MRI_no_prior = @(ind, meas) ADMM_MRI(u_init, ind, meas, Prox_J, nIter, rho, tol);

% Reconstruct using ADMM
tic; u = ADMM_MRI_no_prior(ind, d.meas); toc;

% Show the reconstructed image
figure(2)
subplot(222); imagesc(u); axis image; colormap gray; title('reconstructed image'); colorbar;

%% Step II.1.1*. Reconstruction without a prior of a different sampling
% Select another data set
d = data.sampling13;

% Compute the k-space representation of the data set
ind = MRI_freq2ind(d.freq, s_kspace);
kspace_data = MRI_sample_index_backward(d.meas, ind, s_kspace);
% Show the data
figure(2)
subplot(223); imagesc(log(abs(kspace_data))); axis image; colorbar; title(sprintf('log abs kspace, %3.2f%% data', numel(d.meas)/numel(kspace_data)*100));

% Reconstruct using ADMM with the same parameters as before
tic; u = ADMM_MRI_no_prior(ind, d.meas); toc;

% Show the reconstructed image
figure(2);
subplot(224); imagesc(u); axis image; colormap gray; title('reconstructed image'); colorbar;

%% TASK*: 
% You reconstructed two different images from two different sampling
% schemes. How do the reconstructed images differ?
%
% Get a feeling for this type of reconstruction. Choose different data 
% samplings and parameters. How do different samplings influence the 
% reconstruction?
% 
% OPTIONAL: Change the nonnegativity constraint. Choose either no
% constraint or a box constraint [a,b]. What do you have to do to implement
% this?

%% Step II.2. Reconstruction with a Total Variation (TV) Prior
% Now we will employ a total variation prior. To change the prior we have to
% change the prox operator.

% Select a again a data set
% load training_data/phantom/data_phantom.mat
load training_data/scan1/scan1_data.mat
% load test_data/scan2/scan2_data.mat
d = data.sampling1;

% Compute the k-space representation of the data set
ind = MRI_freq2ind(d.freq, s_kspace);
kspace_data = MRI_sample_index_backward(d.meas, ind, s_kspace);

% Show the data
figure(3)
subplot(221); imagesc(log(abs(kspace_data))); axis image; colorbar; title(sprintf('log abs kspace, %3.2f%% data', numel(d.meas)/numel(kspace_data)*100));

% Choose the prox operator that includes the total variation and the 
% non-negativity constraint. This has been implement by an iterative
% procedure (fast gradient projection).
options.PC = @(x) max(x,0);
Prox_J = @(x, rho, p, alpha) FGP_TV(reshape(x, s_kspace), alpha/rho, 5, options, p);

% Create a function handle that applies the TV reconstruction
ADMM_MRI_TV = @(ind, meas, alpha) ADMM_MRI(u_init, ind, meas, @(x, rho, p)Prox_J(x, rho, p, alpha), nIter, rho, tol);

% The parameter "alpha" is a very important parameter, sometimes also
% called the regularization parameter. It defines the weight given to the
% a priori knowledge compared to the measured data.
alpha = 1e-2;

% Reconstruct using ADMM
tic; u = ADMM_MRI_TV(ind, d.meas, alpha); toc;

% Show the reconstructed image
figure(3)
subplot(222); imagesc(u); axis image; colormap gray; title('reconstructed image'); colorbar;

%% Step II.2.1*. Reconstruction with a TV Prior of a different sampling
% Choose another sampling and run TV penalized reconstruction.

% Select the sampling
d = data.sampling7;

% Compute the k-space representation of the data set
ind = MRI_freq2ind(d.freq, s_kspace);
kspace_data = MRI_sample_index_backward(d.meas, ind, s_kspace);

% Show the data
figure(3)
subplot(223); imagesc(log(abs(kspace_data))); axis image; colorbar; title(sprintf('log abs kspace, %3.2f%% data', numel(d.meas)/numel(kspace_data)*100));

% Reconstruct using ADMM
tic; u = ADMM_MRI_TV(ind, d.meas, alpha); toc;

% Show the reconstructed image
figure(3)
subplot(224); imagesc(u); axis image; colormap gray; title('reconstructed image'); colorbar;

%% TASK*:
% Compare your TV results with the results without a prior. Do you see a
% difference?

%% Step II.3. Choose the regularization parameter for TV
% The most important parameter in reconstructing with a prior is the
% regularization parameter. We will first choose the parameter for the
% training data case where we know the ground truth solution / gold
% standard.

%% Step II.3.1 Qualitative comparison

% Select the training data
load training_data/scan1/scan1_data.mat

% Choose a sampling
d = data.sampling7;
ind = MRI_freq2ind(d.freq, s_kspace);

% Choose a range of parameters
alphas = 10.^[-5 -4 -3.5 -3 -2.5 -2 -1.5 -1];

% Initalize a cell array for the solutions
u = cell(length(alphas),1);

% Reconstruct using ADMM
for i = 1 : length(alphas)
    alpha = alphas(i);
    tic; u{i} = ADMM_MRI_TV(ind, d.meas, alpha); toc;
end

% Show the reconstructed image
for i = 1 : length(alphas)
    alpha = alphas(i);
    figure(4); subplot(2,4,i); imagesc(u{i}); axis image; colormap gray; title(sprintf('alpha = %3.2e', alpha)); colorbar;
end

%% TASK*: 
% Figure 4 shows solutions for different parameters. Which solution do
% you think is the best?

%% Step II.3.2 Quantitative comparison
% As we do know the ground truth for this data we can compare the
% reconstructions to it.

% Load ground truth
load training_data/scan1/scan1_ground_truth.mat

% Compute the PSNR and SSIM for the solutions. These are well-established
% quality measures and widely used in image processing. If you are
% interested you can read the MATLAB documentation for them. For us the 
% most important information is that we want to maximize them, i.e. a larger
% value indicates a better match.
psnrs = zeros(length(alpha), 1);
ssims = zeros(length(alpha), 1);
for i = 1 : length(alphas)
    i
    psnrs(i) = psnr(u{i}, ground_truth);
    ssims(i) = ssim(u{i}, ground_truth);
end

% Show quantitative values
figure(5)
subplot(121); semilogx(alphas, psnrs); xlabel('alpha'); ylabel('PSNR [dB]')
subplot(122); semilogx(alphas, ssims); xlabel('alpha'); ylabel('SSIM')

%% TASK*:
% Does the optimal regularization parameter coincides with your personal
% choice?

%% Step II.3.3* Choice of regularization parameter without ground truth data
% Without ground truth data, the previous computations are not possible.
% Instead the so called "L-Curve" is often employed. It computes for each
% value of the regularization parameter the solution. It then plots the
% data fidelity and prior value on a log-log scale. This curve usually has
% the shape of an "L" and the "L-Curve" rule says, that one should pick the
% value that corresponds to the kink of the "L" (point of highest
% curvature).
%
% If you are interested in more detail, see:
% [1] Hansen, Per Christian. The L-curve and its use in the numerical treatment of inverse problems. 
% IMM, Department of Mathematical Modelling, Technical Universityof Denmark, 1999.
% https://www.sintef.no/globalassets/project/evitameeting/2005/lcurve.pdf
    
% For the data fidelity term we need to define the forward operator
S = @(x) MRI_sample_index_forward(ind, x); % Sampling
F = @(x) Column(Ufftn(reshape(x, s_kspace))); % Fourier operator
A = @(x) S(F(x)); % Forward operator

% Select some prior options. Note that the "L-Curve" rule says that we
% should compute the prior without its regularization parameter.
prior_options.s_image = s_kspace;  
prior_options.alpha = 1;

% Compute the data fidelity and prior value
datafit = zeros(length(alpha), 1);
prior = zeros(length(alpha), 1);
for i = 1 : length(alphas)
    i
    datafit(i) = sum(abs(S(F(u{i})) - d.meas).^2)/2;
    prior(i) = Penalty_TV(prior_options, u{i});
end

% Show the curve
figure(6);
subplot(211); loglog(datafit, prior); xlabel('data fit'); ylabel('prior'); title('L-Curve');
for i = 1 : length(alphas)
    text(datafit(i), prior(i), sprintf('%3.2e', alphas(i)))
end
% axis([7e-2 2e+2 4e+2 1.6e+3]);

% and a close up on the kink
subplot(212); loglog(datafit, prior); xlabel('data fit'); ylabel('prior'); title('L-Curve (close up)');
for i = 1 : length(alphas)
    text(datafit(i), prior(i), sprintf('%3.2e', alphas(i)))
end
axis([1e-1 2e-1 2.7e+3 3.5e+3]);

%% TASK*:
% Which value would the L-curve select? Does this correspond to the
% "optimal" value in terms of PSNR or SSIM? Is this the same as your
% visually preferred choice?

%% Part III. MRI Reconstruction with complementary side information
% In the previous part we have reconstructed from MRI data either without
% a priori information or with the a priori information that the image is 
% simple in the sense that it has a low total variation / has a sparse 
% gradient / is cartoon like.
% 
% This part deals with another kind of a priori information that may come
% from a different MRI contrast. This means that we want to find an image
% that matches the MRI data but is also "similar" to our complementary side
% information.
% 
% Select a data set
% load training_data/phantom/data_phantom.mat
load training_data/scan1/scan1_data.mat
% load test_data/scan2/scan2_data.mat
d = data.sampling7;
ind = MRI_freq2ind(d.freq, s_kspace);

% Load the complementary side information and ground truth data
load training_data/scan1/scan1_ground_truth.mat
load training_data/scan1/scan1_side_information.mat

% Show ground truth and side information.
% Although these two images look rather similar, it is difficult to
% mathematically exploit the similarity in structure.
figure(7)
subplot(221); imagesc(ground_truth); axis image; colormap gray; colorbar; title('ground truth');
subplot(222); imagesc(side_information); axis image; colormap gray; colorbar; title('side info');

%% Step III.1. Reconstruction with a Weighted Total Variation Prior

%% Step III.1.1. Compute the weights
% The complementary side information can be included into a prior with a
% spatial weighting function. We want to penalize edges that correspond to 
% edges in our side information less than edges that are not present in the 
% side information.

% Compute weights
g = Gradient2D_forward_constant_unitstep(side_information);
n = Norm_n(g,0,3);
weights = @(eta) eta./sqrt(n.^2 + eta^2);

% Show weights. For nice visualization we choose eta relatively large.
figure(7);
subplot(223); Image_weights(weights(1e-1)); axis image; colorbar; title('weigths of side info');

%% Step III.1.2. Perform the actual reconstruction
% Define prox operator for weighted total variation
Prox_J = @(x, rho, p, alpha, weights) FGP_wTV(reshape(x, s_kspace), alpha/rho, 5, weights, options, p);

% Create a function handle that applies the reconstruction with weighted TV
ADMM_MRI_wTV = @(ind, meas, alpha, weights) ADMM_MRI(u_init, ind, meas, @(x, rho, p)Prox_J(x, rho, p, alpha, weights), nIter, rho, tol);

% Compute solution for no prior, TV and weighted TV
alpha = 5e-3;
tic; u_np = ADMM_MRI_no_prior(ind, d.meas); toc;
tic; u_TV = ADMM_MRI_TV(ind, d.meas, alpha); toc;
tic; u_wTV = ADMM_MRI_wTV(ind, d.meas, alpha, weights(1e-2)); toc;

% Show solution
figure(8)
subplot(221); imagesc(u_np); axis image; colorbar; colormap gray; title('no prior');
subplot(222); imagesc(u_TV); axis image; colorbar; colormap gray; title('TV');
subplot(223); imagesc(u_wTV); axis image; colorbar; colormap gray; title('weighted TV');

%% Step III.2. Reconstruction with a Directional Total Variation Prior
% By looking at the ground truth and the side information we see that the
% edges not only are at the same location, but they are also in the same
% direction as both images come from the same anatomy.

%% Step III.2.1. Compute vector field
% To make use of this observation we compute a vector field that is normal
% to the edges in the side information.
g = Gradient2D_forward_constant_unitstep(side_information);
n = Norm_n(g,0,3);
vector_field = @(eta) Vec2D_mult(g,(n.^2 + eta^2).^(-1/2));

% Show vector field. We plot the vector field by its magnitude and 
% orientation. The magnitude defines the itensity of the plot and the
% orientation of the line it spans defines the colour.
figure(7)
subplot(224); Image_vector_field(vector_field(1e-1)); axis image;  colorbar; title('vector field of side info; colorbar: magnitude');
colormap gray;

%% Step III.2.2. Reconstruct with directional total variation
% Define prox operator for directional total variation
Prox_J = @(x, rho, p, alpha, vectorfield) FGP_dTV(reshape(x, s_kspace), alpha/rho, 5, vectorfield, options, p);

% Create a function handle that applies the reconstruction with weighted TV
ADMM_MRI_dTV = @(ind, meas, alpha, vectorfield) ADMM_MRI(u_init, ind, meas, @(x, rho, p)Prox_J(x, rho, p, alpha, vectorfield), nIter, rho, tol);

% Compute solution for directional TV
tic; u_dTV = ADMM_MRI_dTV(ind, d.meas, alpha, vector_field(1e-2)); toc;

% Show solution
figure(8)
subplot(224); imagesc(u_dTV); axis image; colorbar; colormap gray; title('directional TV');

%% Step III.2.3. Show close ups
I = 70:150; J = 20:140; % close up region
figure(9)
subplot(221); imagesc(u_np(I,J)); axis image; colorbar; colormap gray; title('no prior');
subplot(222); imagesc(u_TV(I,J)); axis image; colorbar; colormap gray; title('TV');
subplot(223); imagesc(u_wTV(I,J)); axis image; colorbar; colormap gray; title('weighted TV');
subplot(224); imagesc(u_dTV(I,J)); axis image; colorbar; colormap gray; title('directional TV');

%% TASK*: 
% Compare the reconstructions in figures 8 and 9. Which of these methods
% performed the best? Given that "no prior" and "TV" used the same data which
% of these two performed better? Similarly did "weighted TV" perform better
% than "directional TV"?

%% Part IV*: Do it yourself

%% TASK*:
% You now have all the tools available. Play around with the options, 
% reconstruct from different data sets and compare the methods.
