function frequencies = MRI2_sample_random_Gaussian(s_kspace, n_samples, sigma)
% MRI2_sample_random_Gaussian
%   frequencies = MRI_sample_random(s_kspace, n_samples, sigma) samples the 
% k-space randomly with a Gaussian probability distribution.
%
% Input:
%   s_kspace [vector]
%       size of the kspace%
%   n_samples [int]
%       the number of samples
%   sigma [vector]
%       standard deviations of the Gaussian
%
% Output:
%   frequencies [matrix]
%       output matrix of size n x n_samples. Each column specifies the
%       coordinates of a sample point in k-space.
%
% See also:
%
% -------------------------------------------------------------------------
%   changes:
% 
% 2015-11-12 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
    
    if numel(sigma) == 1; sigma = sigma * [1 1]; end;
    if n_samples > prod(s_kspace); error('This model does not allow more samples than kspace size: %i > %i', n_samples, prod(s_kspace)); end;
    
    [x, y] = meshgrid(-s_kspace(1)/2:s_kspace(1)/2-1,-s_kspace(2)/2:s_kspace(2)/2-1);
    x = x./sigma(1);
    y = y./sigma(2);
    probability_distribution = exp(-(x.^2+y.^2));
    
    frequencies = MRI2_sample_random_variable_density(s_kspace, n_samples, probability_distribution);
        
end