function u_out = ADMM_MRI(u_init, ind, data, Prox_J, nIter, rho, tol)
% MRI2_ADMM
%   [u, stats] = MRI2_ADMM(MRI_data, ADMM_options, prior_options) runs
% an ADMM algorithm to reconstruct MRI with a non-differentiable prior.
%
% Input:
%   MRI_data [struct]
%       struct of MRI data. The fields are
%           MRI_data.data [complex vector]
%               actual imaging data
%           MRI_data.index [int vector]
%               the indices where the data was sampled
%           MRI_data.s_kspace [int vector]
%               the size of the kspace
%
% Output:
%   u [vector]
%       final iterate
%
% See also:
%
% -------------------------------------------------------------------------
%   changes:
%
% 2015-10-14 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2016 University of Cambridge
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    s_image = size(u_init);
    s_kspace = s_image;

    u_init = Column(u_init);

    % set operators
    S = @(x) MRI_sample_index_forward(ind, x); % sampling
    Sadj = @(x) Column(MRI_sample_index_backward(x, ind, s_kspace)); % backwards sampling
    F = @(x) Column(Ufftn(reshape(x, s_image))); % Fourier operator
    Fadj = @(x) real(Column(Uifftn(reshape(x, s_image)))); % inverse Fourier operator

    Sd = Sadj(data);

    zeroimage = Column(zeros(s_image));
    n_pixel = prod(s_image);

    I = 1:n_pixel;
    J = n_pixel+1:2*n_pixel;

    % initialize
    ones_array = ones(s_kspace);
    D = (Sadj(S(ones_array)) + rho).^(-1); % (number of sample at this location + rho) inverse

    A = @(x) x;
    B = @(x) [x; F(x)];

    eta = [zeroimage; zeroimage];
    By = B(u_init);
    p = zeros([s_image 2]);

   u = Column(u_init);
    for k = 1 : nIter

        % First block
        [uu, p] = Prox_J(By(I) - eta(I), rho, p);
        uu = Column(uu);

        v = D.* ( Sd + rho*By(J) - eta(J) );

        x = [uu; v];
        Ax = A(x);

        % Second block
        y = 1/2 * ( Ax(I) + eta(I) + Fadj(Ax(J) + eta(J)) );
        By = B(y);

        % update multipliers
        eta = eta + rho*(Ax - By);

%         diff = norm(u - uu, 'inf') / mean(abs(uu));
        diff = norm(u - uu) / norm(uu);
        if diff < tol
            fprintf('Iteration %4d: Tolerance reached: difference between iterates %2.2e < %2.2e\n', k, diff, tol);
            break            
        else
            fprintf('Iteration %4d: difference between iterates: %2.2e > %2.2e\n', k, diff, tol);
        end
        
        u = uu;
    end

    u_out = reshape(u(I), s_image);
end