function x = Log_range(a,b,n)
    x = 10.^(linspace(log10(a), log10(b), n));
end