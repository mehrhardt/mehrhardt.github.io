run JR_data;
load JR_data_spiralHigh.mat
P = @(x)(options{index.mri}.undersampling_forward(x));
Q = @(x)(options{index.mri}.undersampling_backward(x));
operator{index.mri} = @(x)(JR_column(P(JR_ufft2(Im(x)))));
adjoint{index.mri} = @(x)(JR_column(real(JR_uifft2(Q(x)))));
