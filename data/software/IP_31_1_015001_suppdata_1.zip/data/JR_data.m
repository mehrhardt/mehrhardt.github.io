load JR_data.mat
load JR_matrix.mat
Im = @(x)(reshape(x,options{index.misc}.size));
Si = @(x)(reshape(x,options{index.pet}.size_sinogram));
operator{index.pet} = @(x)(options{index.pet}.scaling*JR_column(imfilter(Si(pet_matrix*JR_column(x)),options{index.pet}.psf)));
adjoint{index.pet} = @(x)(pet_matrix'*JR_column(imfilter(Si(x),options{index.pet}.psf)));
operator{index.mri} = @(x)(JR_column(JR_ufft2(Im(x))));
adjoint{index.mri} = @(x)(JR_column(real(JR_uifft2(Im(x)))));
