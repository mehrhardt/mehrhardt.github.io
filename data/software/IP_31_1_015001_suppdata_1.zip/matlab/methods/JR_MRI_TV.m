function [solution, converged, parts] = JR_MRI_TV(x_0, param, data, operator, adjoint, solver_options)
% JR_MRI_TV
%   [solution, converged, parts] = JR_MRI_TV(x_0, param, data, operator, adjoint, solver_options)
% solves a least squares inverse problem with total variation as a prior.
% 
% Input:    
%   x_0 [vector]              
%       initial estimate; if numel(x_0) <= 2 then the algorithm is
%       initialized with a zero estimate
%
%   param [vector]              
%       parameters needed for the prior; param(1) is an overall scaling and
%       param(2) a "smoothing" to make the prior differentiable
%
%   data [vector]
%       data as a vector.
%
%   operator [function_handle]       
%       forward operator implemented as a function handle. The output 
%       should be a vector for consistency but ought to match the data.
%
%   adjoint [function_handle]  
%       adjoint ("transpose") of the forward operator implemented as a 
%       function handle. The output should be a vector.
%
%   solver_options [struct; optional]            
%       options for the L_BFGS_B solver
%
% Output:
%   fun [scalar]
%       function value at the input u.
%
%   grad [vector]
%       gradient of the likelihood evaluated at the input u.
%
%   parts [vector]
%       values of the parts of the corresponding objective function
%
% See also: JR_L_BFGS_B
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if nargin < 6; solver_options = []; end
    if numel(x_0) <= 2; x_0 = zeros(x_0); end
    
    Im = @(x) reshape(x, size(x_0));
    
    if nargin < 4 || numel(operator) == 0
        operator = @(x) (x(:));
        adjoint = @(x) (Im(x));
    end
    
    alpha = param(1);
    beta = param(2);
    
    fun = @(x) (obj(Im(x), alpha, beta, data(:), operator, adjoint));

    % set starting image
    u0 = JR_column(x_0);

    [solution, converged] = JR_L_BFGS_B(u0, fun, [], [], solver_options);
    solution = Im(solution);
    
    [~,~,parts] = fun(solution);
    
end

function [fun, grad, extra] = obj(x, alpha, beta, data, operator, adjoint)

    % TV prior
    if nargout > 1;
        [f2, g2] = JR_TV(beta, x);
    else
        f2 = JR_TV(beta, x);
    end

    % data
    res = operator(x) - data;
    f1 = 0.5 * sum(abs(res(:)).^2);
    if nargout > 1; g1 = adjoint(res); end;

    % sum both components up
    fun = f1 + alpha * f2;
    if nargout > 1; grad = g1 + alpha * g2; end;

    extra = [f1; alpha*f2];

end