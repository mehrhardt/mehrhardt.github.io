function JR_PETMRI_QPLS_wrapper(sampling, alpha, beta)
% JR_PETMRI_QPLS_wrapper
%   JR_PETMRI_QPLS_wrapper(sampling, alpha, beta) is a wrapper for JR_PETMRI_QPLS. 
% It loads the data, runs the algorithms and saves the results
% 
% Input:
%   sampling [string]       
%       used to read the data and to write the solution
%
%   alpha [scalar]              
%       an overall scaling for the prior
%
%   beta [scalar]              
%       "smoothing" to make the prior differentiable
%
% See also: JR_PETMRI_QPLS
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    name = ['JR_PETMRI_' sampling '_QPLS'];
    run(fullfile('..', 'data', ['JR_data_' sampling '.m']));
    folder_results = fullfile('..', 'results', name);
    mkdir(folder_results);
    
    param = [alpha, beta];        
    load (fullfile('..', 'data', ['JR_initial_QPLS_' sampling '.mat']))    
    % Rec
    [solution, converged, parts] = JR_PETMRI_QPLS(initial_images, ..., 
        data{index.pet}, operator{index.pet}, adjoint{index.pet}, 1e-3, ...
        data{index.mri}, operator{index.mri}, adjoint{index.mri}, options{index.mri}.sigma_abs, ...
        param);
    
    err = JR_joint_error(solution, ground_truth{index.pet}, ground_truth{index.mri});

    JR_save_joint_results(err, converged, solution, param, parts, {'QPLS alpha', 'QPLS beta'}, ...
        ground_truth, [folder_results '/' name]);
    
end