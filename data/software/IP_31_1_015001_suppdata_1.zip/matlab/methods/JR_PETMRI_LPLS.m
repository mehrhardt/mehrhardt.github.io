function [solution, converged, parts] = JR_PETMRI_LPLS(x_0, ...
    pet_data, pet_operator, pet_adjoint, pet_eta, ...
    mri_data, mri_operator, mri_adjoint, mri_sigma, ...
    param, solver_options)
% JR_PETMRI_LPLS
%   [solution, converged, parts] = JR_PETMRI_LPLS(x_0, ...
%   pet_data, pet_operator, pet_adjoint, pet_eta, ...
%   mri_data, mri_operator, mri_adjoint, mri_sigma, ...
%   param, solver_options)
% solves a joint minimization problem where the objective functional 
% consists of a PET fidelity, MRI fidelity and linear parallel level 
% sets as a prior.
% 
% Input:    
%   x_0 [cell]              
%       initial estimate; if x_0 is not a cell and numel(x_0) <= 2 then the
%       algorithm is initialized with the lower bound pet_eta for PET and
%       zeros for MRI
%
%   pet_data [vector]
%       PET data
%
%   pet_operator [matrix or function handle]
%       maps input into the sinogram space; projection
%
%   pet_adjoint [matrix or function handle]
%       adjoint of the operator; backprojection
%
%   mri_data [vector]
%       MRI data; k-space
%
%   mri_operator [matrix or function handle]
%       maps input into the k-space; Fourier transform plus sampling
%
%   mri_adjoint [matrix or function handle]
%       adjoint of the operator; zero filling and inverse Fourier transform 
%
%   mri_sigma [scalar]
%       estimated standard deviation of the noise in k-space
%
%   param [vector]
%       parameters for the prior. param(1) is the overall scaling and
%       param(2) the "smoothing". param(3) and param(4) may specify some
%       weights of the data term but this is optional.
%
%   solver_options [struct; optional]            
%       options for the L_BFGS_B solver
%
% Output:
%   fun [scalar]
%       function value at the input u.
%
%   grad [vector]
%       gradient of the likelihood evaluated at the input u.
%
%   parts [vector]
%       values of the parts of the corresponding objective function
%
% See also: JR_L_BFGS_B JR_Poisson_Gaussian_LPLS JR_LPLS JR_Poisson_Gaussian
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if nargin < 11; solver_options = []; end;
        
    if  ~iscell(x_0) 
        if numel(x_0) <= 2
            tmp = x_0;
            clear x_0;
            x_0{1} = pet_eta*ones(tmp);
            x_0{2} = zeros(tmp);
        end
    else
        if numel(x_0{1}) <= 2
            tmp = x_0{1};
            x_0{1} = pet_eta*ones(tmp);
        end
        if numel(x_0{2}) <= 2
            tmp = x_0{2};
            x_0{2} = zeros(tmp);
        end    
    end
            
    s_image = size(x_0{1});
    
    x_0 = JR_images2vector(x_0);
       
    fun = @(x) JR_Poisson_Gaussian_LPLS(x, s_image, ...
    pet_data, pet_operator, pet_adjoint, ...
    mri_data, mri_operator, mri_adjoint, mri_sigma, ...
    param);
        
    N = length(x_0)/2;
    l = [pet_eta * ones(N,1); -inf*ones(N,1)];
    u = [];
    [solution, converged] = JR_L_BFGS_B(x_0, fun, l, u, solver_options);  
    
    if nargout > 2; [~,~,parts] = fun(solution); end;
    solution = JR_vector2images(solution, s_image);
    
end