function [solution, converged, parts] = JR_PET(x_0, data, operator, adjoint, maxIts)
% JR_PET
%   JR_PET(x_0, data, operator, adjoint, maxIts) minimizes a negative Poisson
%   log-likelihood by means of the MLEM algorithm. The problem is
%   regularized by early termination.
% 
% Input:    
%   x_0 [vector]              
%       initial estimate; if numel(x0) <= 2 then the algorithm is
%       initialized with ones
%
%   data [vector]
%       data as a vector.
%
%   operator [function_handle]       
%       forward operator implemented as a function handle. The output 
%       should be a vector for consistency but ought to match the data.
%
%   adjoint [function_handle]  
%       adjoint ("transpose") of the forward operator implemented as a 
%       function handle. The output should be a vector.
%
%   maxIts [int]              
%       number of iterations
%
% Output:
%   fun [scalar]
%       function value at the input u.
%
%   grad [vector]
%       gradient of the likelihood evaluated at the input u.
%
%   parts [vector]
%       values of the parts of the corresponding objective function
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if numel(x_0) <= 2; x_0 = ones(x_0); end;
      
    s_image = size(x_0);
    
    x_old = JR_column(x_0);
    sens = adjoint(ones(size(data)));
    sens = max(sens, 1);
    
    converged = -1;
    
    for i = 1:maxIts
        Opx = operator(x_old);
        res = data./(Opx + 1e-12);
        x_new = x_old ./ sens .* adjoint(res);
        
        if max(norm(x_new-x_old, 'inf')) < 1e-5
            converged = i;
            break;
        end
        
        x_old = x_new;
    end
    
    ii = data>0;
    datalogres = zeros(size(res));
    datalogres(ii) = data(ii).*log(res(ii));
    parts = sum(sum(datalogres + Opx - data));
    
    solution = reshape(x_old, s_image);
   
end