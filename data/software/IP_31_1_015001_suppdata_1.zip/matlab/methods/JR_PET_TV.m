function [solution, converged, parts] = JR_PET_TV(x_0, data, operator, ...
    adjoint, eta, param, solver_options)
% JR_PET_TV
%   [solution, converged, parts] = JR_PET_TV(x_0, data, operator, adjoint, eta, param, solver_options)
% solves a minimization problem where the objective functional consists of 
% of the negative Poisson log-likelihood and a total variation prior.
% 
% Input:    
%   x_0 [vector]              
%       initial estimate; if numel(x0) <= 2 then the algorithm is
%       initialized with the lower bound eta
%
%   data [vector]
%       data as a vector.
%
%   operator [function_handle]       
%       forward operator implemented as a function handle. The output 
%       should be a vector for consistency but ought to match the data.
%
%   adjoint [function_handle]  
%       adjoint ("transpose") of the forward operator implemented as a 
%       function handle. The output should be a vector.
%
%   eta [scalar]              
%       lower bound of the positivity contraint
%
%   param [vector]              
%       parameters needed for the prior; param(1) is an overall scaling and
%       param(2) a "smoothing" to make the prior differentiable
%
%   solver_options [struct; optional]            
%       options for the L_BFGS_B solver
%
% Output:
%   fun [scalar]
%       function value at the input u.
%
%   grad [vector]
%       gradient of the likelihood evaluated at the input u.
%
%   parts [vector]
%       values of the parts of the corresponding objective function
%
% See also: JR_L_BFGS_B
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if nargin < 7; solver_options = []; end;
    if numel(x_0) <= 2; x_0 = eta*ones(x_0); end
        
    s_image = size(x_0);
    x_0 = JR_column(x_0);
    
    fun = @(x) JR_Poisson_TV(x, s_image, data, operator, adjoint, param);
        
    [solution, converged] = JR_L_BFGS_B(x_0, fun, eta * ones(size(x_0)), [], solver_options);  
    
    if nargout > 2; [~,~,parts] = fun(solution); end    
    solution = reshape(solution, s_image);
    
end