% JR_PETMRI_JTV_script
%   JR_PETMRI_JTV_script.m runs JR_PETMRI_JTV_wrapper which reconstructs 
% from Poisson distributed PET data and undersampled MRI data using a joint
% total variation prior.
%
% See also: JR_PETMRI_JTV_wrapper JR_PETMRI_JTV
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

clear all; clf; 

JR_PETMRI_JTV_wrapper('full', 1.39e+00, 7.20e-04) 
JR_PETMRI_JTV_wrapper('lines2', 2.78e+00, 7.25e-04)  
JR_PETMRI_JTV_wrapper('radial20', 2.44e+00, 2.15e-04)
JR_PETMRI_JTV_wrapper('radial15', 1.34e+00, 1.00e-04)
JR_PETMRI_JTV_wrapper('spiralHigh', 5.18e+00, 1.93e-03)
JR_PETMRI_JTV_wrapper('spiralUni', 2.68e+00, 1.93e-03)