function [fun, grad] = JR_TV(beta, varargin)
% JR_TV
%   [fun, grad] = JR_TV(beta, varargin) computes the total variation prior 
% for either a cell or a list of input images.
% 
% Input:  
%   beta [float]            
%       this parameter sets "how smooth" the total variation prior should 
%       be approximated
%
%   varargin [cell or list]              
%       the images where we want to compute the total variation prior. This
%       can be either a cell or a list of images.
%
% Output:
%   fun [scalar]
%       function value of the total variation prior
%
%   grad [vector]
%       gradient of the total variation prior
%
% See also: JR_PET_TV JR_MRI_TV
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    % handle input
    if iscell(varargin{1})
        input = varargin{1};
    else
        input = varargin;
    end
    
    K = length(input);
    fun = zeros(size(input{1}));
    
    if nargout > 1
        c = numel(input{1});
        grad = zeros(c*K, 1);
    end
    
    for k = 1 : K
        % calulate the gradient
        G = JR_gradient(input{k}, 'constant', 'forward');
        % and store its norm
        N = JR_norm3(G, beta);
            
        fun = fun + N;
        
        if nargout > 1; grad((k-1) * c + (1 : c)) = - JR_diffusion(1./N, G); end;
    end
           
    fun = sum(fun(:));
    
end