function [fun, grad] = JR_JTV(beta, varargin)
% JR_JTV
%   [fun, grad] = JR_JTV(beta, varargin) computes the joint total variation 
% prior for either a cell or a list of input images.
% 
% Input:  
%   beta [float]            
%       this parameter sets "how smooth" the joint total variation prior 
%       should be approximated
%
%   varargin [cell or list]              
%       the images on which we want to compute the joint total variation 
%       prior. This can be either a cell or a list of images.
%
% Output:
%   fun [scalar]
%       function value of the joint total variation prior
%
%   grad [vector]
%       gradient of the joint total variation prior
%
% See also: JR_PETMRI_JTV
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    % handle input
    if iscell(varargin{1})
        input = varargin{1};
    else
        input = varargin;
    end
    
    K = length(input);
    fun = beta^2*ones(size(input{1}));
    
    if nargout > 1
        c = numel(input{1});
        grad = zeros(c*K, 1);
    end
    
    G = cell(K,1);
    
    for k = 1 : K
        % calulate the gradient
        G{k} = JR_gradient(input{k}, 'constant', 'forward');
        % and store its norm
        N = JR_norm3(G{k}, 0);
            
        fun = fun + N.^2;
    end
    
    fun = sqrt(fun);
    
    if nargout > 1
        for k = 1 : K
            kappa = 1./fun;
            grad((k-1) * c + (1 : c)) = - JR_diffusion(kappa, G{k});
        end
    end
           
    fun = sum(fun(:));
    
end