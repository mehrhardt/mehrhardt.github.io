function [fun, grad] = JR_QPLS(beta, varargin)
% JR_QPLS
%   [fun, grad] = JR_QPLS(beta, varargin) computes the quadratic parallel 
% level set prior for either a cell or a list of input images.
% 
% Input:  
%   beta [float]            
%       smoothness parameter for quadratic parallel level sets
%
%   varargin [cell or list]              
%       the images on which we want to compute the quadratic parallel level 
%       sets prior. This can be either a cell or a list of images.
%
% Output:
%   fun [scalar]
%       function value of the quadratic parallel level sets prior
%
%   grad [vector]
%       gradient of the quadratic parallel level sets prior
%
% See also: JR_PETMRI_QPLS 
%
% 2014-02-25 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
    
    [K, images] = JR_get_images(varargin);
    [G,N,A] = JR_gradients_norms_angles(images, beta);
                    
    if nargout > 1
        c = numel(images{1});
        grad = zeros(c*K, 1);
    end
        
    rho = Compute_rho(1, N, A);

    % compute kappa and tau
    if nargout > 1        
        for u = 1 : K 
            % set index range of this image in the gradient
            I = (u-1) * c + (1 : c);
            
            kappa = zeros(size(images{1}));
            
            for v = 1 : K
                if v ~= u
                    kappa = kappa + N{v}.^2;
                    tau = - A{u,v};
                    grad(I) = grad(I) - JR_diffusion(tau./ rho, G{v});
                end
            end
            
            grad(I) = grad(I) - JR_diffusion(kappa./ rho, G{u});
        end
    end
        
    fun_image = rho;
    fun = sum(fun_image(:));
    
end

function rho = Compute_rho(beta, N, A)
    
    K = length(N);

    % compute rho
    rho = ones(size(N{1}));
    for u = 1 : K
        for v = u+1 : K
            rho = rho + (N{u}.^2 .* N{v}.^2 - JR_norm3(A{u,v}, beta^2).^2);
        end
    end
        
    if min(rho(:)) < 0
        rho = inf;
    else
        rho = sqrt(rho);
    end
    
end