function [fun, grad, fun_image] = JR_LPLS(beta, varargin)
% JR_LPLS
%   [fun, grad] = JR_LPLS(beta, varargin) computes the linear parallel level 
% set prior for either a cell or a list of input images.
% 
% Input:  
%   beta [float]            
%       smoothness parameter for linear parallel level sets
%
%   varargin [cell or list]              
%       the images on which we want to compute the linear parallel level 
%       sets prior. This can be either a cell or a list of images.
%
% Output:
%   fun [scalar]
%       function value of the linear parallel level sets prior
%
%   grad [vector]
%       gradient of the linear parallel level sets prior
%
% See also: JR_PETMRI_LPLS 
%
% 2014-02-25 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
    
    [K, images] = JR_get_images(varargin);
    [G,N,A] = JR_gradients_norms_angles(images, beta);
                    
    if nargout > 1
        n_image = numel(images{1});
        grad = zeros(n_image*K,1);
    end
   
    s_image = size(images{1});
    fun_image = zeros(s_image);
        
    for u = 1 : K
        for v = u+1 : K
            fun_image = fun_image + N{u}.*N{v} - JR_norm3(A{u,v}, beta^2);
        end
    end
    
    % compute kappa and tau
    if nargout > 1        
        for u = 1 : K 
            % set index range of this image in the gradient
            I = (u-1) * n_image + (1 : n_image);
            
            kappa = zeros(s_image);
            
            for v = 1 : K
                if v ~= u
                    kappa = kappa + N{v}./N{u};
                    
                    tau = - A{u,v}./ JR_norm3(A{u,v}, beta^2);
                    grad(I) = grad(I) - JR_diffusion(tau, G{v});
                end
            end
            
            grad(I) = grad(I) - JR_diffusion(kappa, G{u});
        end
    end
       
    fun = sum(fun_image(:));
    
end