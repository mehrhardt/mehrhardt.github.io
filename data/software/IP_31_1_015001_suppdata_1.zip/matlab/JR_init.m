% JR_init
%   JR_init.m adds the necessary paths to run the code. To run the examples
% execute either JR_run_all.m to run all examples or one of the 
% corresponding files for each example.
%
% See also: JR_run_all
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

fprintf('>>> initialize joint reconstruction \n');

this_location = pwd;

addpath(this_location);
addpath([this_location, '/methods']);
addpath([this_location, '/MRI']);
addpath([this_location, '/MRI/undersampling']);
addpath([this_location, '/objectives']);
addpath([this_location, '/penalties']);
addpath([this_location, '/scripts']);
addpath([this_location, '/solver']);
addpath([this_location, '/utils']);

clear this_location;
