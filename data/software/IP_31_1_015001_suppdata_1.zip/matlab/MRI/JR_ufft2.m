function X = JR_ufft2(x)
%JR_ufft2 
%   X = JR_ufft2(x) is the unitary 2D Fourier transform.
%
% Input:    
%   x [matrix]              
%       a two dimensional image
%
% Output:
%   X [matrix]
%       two dimensional x space
%
% See also: JR_uifft2
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
% -------------------------------------------------------------------------

    X = fftshift(fft2(x)) / sqrt(numel(x));
    
end