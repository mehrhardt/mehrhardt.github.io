function x = JR_uifft2(X)
%JR_uifft2 
%   x = JR_uifft2(X) is the unitary 2D inverse Fourier transform.
%
% Input:    
%   X [matrix]
%       two dimensional x space
%
% Output:
%   x [matrix]              
%       a two dimensional image
%
% See also: JR_ufft2
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
% -------------------------------------------------------------------------

    x = ifft2(ifftshift(X)) * sqrt(numel(X));
    
end