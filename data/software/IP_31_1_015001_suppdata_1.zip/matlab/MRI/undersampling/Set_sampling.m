function [P, Q, data_usage, acquisition_string] = Set_sampling(acquisition, s_kspace)
% Set_sampling
%   [P, Q, data_usage, acquisition_string] = Set_sampling(acquisition, s_kspace)
%
% Input:    
%   acquisition [string]
%       which acquistion: 'full', 'radial', 'random', 'random_lines',
%       'lines' or 'spiral'
%
%   s_kspace [vector]
%       size of the k-space
%
% Output:
%   P [function handle]              
%       sampling operator
%
%   Q [function handle]              
%       adjoint of the sampling operator
%
%   data_usage [scalar]              
%       data usage in percent
%
%   acquisition_string [string]              
%       name of the acquistion with parameters
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    switch acquisition.scheme
        case 'full'
            mask_index = 1 : prod(s_kspace);
            data_usage = 1;
            acquisition_string = sprintf('%s', ...
                acquisition.scheme);

        case {'radial'}
            [mask, mask_index] = Mask_non_square(acquisition.n_lines, s_kspace, acquisition.scheme);
            data_usage = numel(mask_index) / numel(mask);
            acquisition_string = sprintf('%s_%i', ...
                acquisition.scheme, acquisition.n_lines(1));

        case {'random'}
            [mask, mask_index] = Mask_non_square_random(acquisition.usage, s_kspace);
            data_usage = numel(mask_index) / numel(mask);
            acquisition_string = sprintf('%s_%3.1f%%', ...
                acquisition.scheme, acquisition.usage*100);

        case {'random_lines'}
            [mask, mask_index] = Mask_non_square_random_lines(acquisition.n_lines, s_kspace);
            data_usage = numel(mask_index) / numel(mask);
            acquisition_string = sprintf('%s_%i_%i', ...
                acquisition.scheme, acquisition.n_lines(1), acquisition.n_lines(2));

        case {'lines'}
            mask = zeros(s_kspace);
            mask(1:acquisition.every_nth_line:end,:) = 1;
            mask_index = find(mask);
            data_usage = s_kspace(1)/acquisition.every_nth_line/100;
            acquisition_string = sprintf('%s_%i', ...
                acquisition.scheme, acquisition.every_nth_line);

        case {'spiral'}
            [mask, mask_index] = Mask_spiral(acquisition.exponent, acquisition.n_turns, acquisition.n_samples, s_kspace);
            data_usage = numel(mask_index) / numel(mask);
            acquisition_string = sprintf('%s_%05.0f_%i_%05.0f', ...
                acquisition.scheme, 1000*acquisition.exponent, acquisition.n_turns, acquisition.n_samples);

    end

    P = @(x) (Undersampling_forward(x, mask_index));
    Q = @(x) (Undersampling_backward(x, mask_index, s_kspace));

end