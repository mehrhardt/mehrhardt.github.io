function [fun, grad, parts] = JR_Poisson_Gaussian_JTV( ...
    x, s_image, ...
    pet_data, pet_operator, pet_adjoint, ...
    mri_data, mri_operator, mri_adjoint, mri_sigma, ...
    param)
% JR_Poisson_Gaussian_JTV
%   [fun, grad, parts] = JR_Poisson_Gaussian_JTV( ...
%   x, s_image, ...
%   pet_data, pet_operator, pet_adjoint, ...
%   mri_data, mri_operator, mri_adjoint, mri_sigma, ...
%   param)
% computes the joint PET-MRI data term plus joint total variation as a prior.
% 
% Input:  
%   x [vector]            
%       the PET-MRI image as a vector; PET first and then MRI
%
%   s_image [vector]
%       the size of the input as an image
%
%   pet_data [vector]
%       PET data
%
%   pet_operator [matrix or function handle]
%       maps input into the sinogram space; projection
%
%   pet_adjoint [matrix or function handle]
%       adjoint of the operator; backprojection
%
%   mri_data [vector]
%       MRI data; k-space
%
%   mri_operator [matrix or function handle]
%       maps input into the k-space; Fourier transform plus sampling
%
%   mri_adjoint [matrix or function handle]
%       adjoint of the operator; zero filling and inverse Fourier transform 
%
%   mri_sigma [scalar]
%       estimated standard deviation of the noise in k-space
%
%   param [vector]
%       parameters for the prior. param(1) is the overall scaling and
%       param(2) the "smoothing". param(3) and param(4) may specify some
%       weights of the data term but this is optional.
%
% Output:
%   fun [scalar]
%       function value
%
%   grad [vector]
%       gradient
%
%   parts [vector]
%       parts of this function
%
% See also: JR_PETMRI_JTV
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if numel(s_image) == 1; s_image = s_image * [1 1]; end;

    alpha = param(1);
    beta = param(2);
    
    if length(param) > 2
        mu1 = param(3);
        mu2 = param(4);
    else
        mu1 = 1;
        mu2 = 1;
    end
    
    x_pet = x(1:end/2);
    x_mri = x(end/2+1:end);
    
    % data
    if nargout > 1
        [fun1, grad1, parts1] = JR_Poisson_Gaussian( ...
            x, s_image, ...
            pet_data, pet_operator, pet_adjoint, ...
            mri_data, mri_operator, mri_adjoint, mri_sigma, ...
            mu1, mu2);
    else
        fun1 = JR_Poisson_Gaussian( ...
            x, s_image, ...
            pet_data, pet_operator, pet_adjoint, ...
            mri_data, mri_operator, mri_adjoint, mri_sigma, ...
            mu1, mu2);
    end
    
    % priors
    u_pet = reshape(x_pet, s_image);
    u_mri = reshape(x_mri, s_image);
    
    % joint prior
    if alpha > 0        
        if nargout > 1
            [fun2, grad2] = JR_JTV(beta, u_pet, u_mri);
            grad2 = alpha * grad2;
        else
            fun2 = JR_JTV(beta, u_pet, u_mri);
        end
        
        fun2 = alpha * fun2;
    else
        fun2 = 0;
        grad2 = 0*x;
    end
       
    % sum up
    if nargout > 1
        grad = grad1 + grad2;
    end
    
    if nargout > 2
        parts = parts1;
        parts(end+1) = fun2;
    end
        
    fun = fun1 + fun2;
    
end