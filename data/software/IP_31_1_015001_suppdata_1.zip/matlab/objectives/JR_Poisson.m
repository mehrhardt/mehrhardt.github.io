function [fun, grad, parts] = JR_Poisson(x, s_image, data, operator, adjoint)
% JR_Poisson
%   [fun, grad, parts] = JR_Poisson(x, s_image, data, operator, adjoint)
% computes the Kullback-Leibler divergence (negative log-likelihood for the
% Poisson distribution).
% 
% Input:  
%   x [vector]            
%       where to evaluate the Kullback-Leibler divergence
%
%   s_image [vector]
%       the size of the input as an image
%
%   data [vector]
%       an instance of a Poisson distribution
%
%   operator [matrix or function handle]
%       maps input x into the sinogram space; projection
%
%   adjoint [matrix or function handle]
%       adjoint of the operator; backprojection
%
% Output:
%   fun [scalar]
%       function value
%
%   grad [vector]
%       gradient
%
%   parts [vector]
%       parts of this function
%
% See also: JR_PET_TV JR_PETMRI_JTV JR_PETMRI_LPLS JR_PETMRI_QPLS
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if numel(s_image) == 1; s_image = s_image * [1 1]; end;
    
    x = reshape(x, s_image);
    
    Opx = JR_apply(operator, x);
    res = data./max(Opx, 1e-6);
    datalogres = zeros(size(res));
    i = data>0;
    datalogres(i) = data(i).*log(res(i));

    fun = sum(datalogres + Opx - data);
    
    if nargout > 1
        if numel(adjoint) > 0
            grad = JR_apply(adjoint, 1 - res);
        else
            grad = JR_apply(operator', 1 - res);
        end       
    end
    
    if nargout > 2
        parts = fun;
    end
    
end