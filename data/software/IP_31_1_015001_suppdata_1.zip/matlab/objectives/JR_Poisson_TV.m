function [fun, grad, parts] = JR_Poisson_TV(x, s_image, data, operator, adjoint, param)
% JR_Poisson_TV
%   [fun, grad, extra] = JR_Poisson_TV(x, s_image, data, operator, adjoint, param)
% computes the PET data term plus total variation as a prior.
% 
% Input:  
%   x [vector]            
%       the PET image as a vector;
%
%   s_image [vector]
%       the size of the input as an image
%
%   data [vector]
%       PET data
%
%   operator [matrix or function handle]
%       maps input into the sinogram space; projection
%
%   adjoint [matrix or function handle]
%       adjoint of the operator; backprojection
%
%   param [vector]
%       parameters for the prior. param(1) is the overall scaling and
%       param(2) the "smoothing".
%
% Output:
%   fun [scalar]
%       function value
%
%   grad [vector]
%       gradient
%
%   parts [vector]
%       parts of this function
%
% See also: JR_PET_TV
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if numel(s_image) == 1; s_image = s_image * [1 1]; end;
       
    alpha = param(1);
    beta = param(2);
    
    % data
    if nargout > 1
        [fun1, grad1, parts] = JR_Poisson( ...
            x, s_image, data, operator, adjoint);
    else
        fun1 = JR_Poisson( ...
            x, s_image, data, operator, adjoint);
    end
    
    % prior
    if alpha > 0
        x = reshape(x, s_image);
        if nargout > 1
            [fun2, grad2] = JR_TV(beta, x);
        else
            fun2 = JR_TV(beta, x);
        end
    else
        fun2 = 0;
        grad2 = 0*x;
    end
        
    fun = fun1 + alpha * fun2;

    if nargout > 1
        grad = grad1 + alpha * grad2;    
        parts(end+1) = alpha * fun2;
    end
    
end