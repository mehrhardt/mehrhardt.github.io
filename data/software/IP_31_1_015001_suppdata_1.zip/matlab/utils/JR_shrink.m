function [x, shrinked] = JR_shrink(x, a, b)
% JR_shrink
%   [x, shrinked] = JR_shrink(x, a, b) shrinks the values of the input 
% image x to the range [a b].
%
% Input:    
%   x [matrix]              
%       scalar valued image
%
%   a [float; optional]              
%       lower bound for projection. DEFAULT = 0
%
%   b [float; optional]              
%       upper bound for projection. DEFAULT = 255
%
% Output:
%   x [matrix]              
%       scalar valued image with values projected to [a b]
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
    
    if nargin < 2
        a = 0;
        b = 255;
    end
    
    M1 = find(x<a);
    M2 = find(x>b);
    
    shrinked = (numel(M1) + numel(M2)) / numel(x);

    x(M1) = a;
    x(M2) = b;
    
end