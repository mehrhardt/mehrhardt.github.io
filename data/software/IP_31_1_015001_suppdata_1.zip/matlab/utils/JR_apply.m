function y = JR_apply(A,x)
% JR_apply
%   y = JR_apply(A,x) applies the matrix or function handle A to x.
%
% Input:    
%   A [matrix or function handle]              
%       operator to be applied to x
%
%   x [vector]              
%       input for Ax / A(x)
%
% Output:
%   y [vector]              
%       y = Ax / A(x)
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if isa(A, 'function_handle')
        y = A(x);
    else
        y = A*JR_column(x);
    end
    
end