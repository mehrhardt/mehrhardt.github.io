function [G,N,A] = JR_gradients_norms_angles(images, beta)
% JR_gradients_norms_angles
%   [G,N,A] = JR_gradients_norms_angles(images) computes gradients, the
% norms and scalar products of these gradients.
%
% Input:    
%   images [cell]              
%       cell array of input images.
%
%   beta [scalar]              
%       smoothing factor for "smooth" norms
%
% Output:
%   G [cell]
%       cell array of gradients
%
%   N [cell]
%       cell array of gradient norms
%
%   A [cell]
%       cell matrix of scalar products of the gradients
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if nargin < 2; beta = 0; end;
    
    K = length(images);

    % cell array for the gradients of all images
    G = cell(K,1);
    % cell array for the pairwise scalar products of the gradients
    A = cell(K, K);
    % cell array for the norms of the gradients
    N = cell(K, 1);   
    
    % For all pairs of images compute their scalar product of the
    % gradients. As the scalar product is symmetric it is sufficient to
    % skip almost half of the pairs.   
    for u = 1 : K        
        % calulate the gradient
        G{u} = JR_gradient(images{u}, 'constant', 'forward');
        % and store its norm
        N{u} = JR_norm3(G{u}, beta);
    end
    
    for u = 1 : K
        for v = 1 : K
            if u ~= v
                if u < v
                    A{u, v} = JR_innerprod3(G{u},G{v});
                else
                    A{u, v} = A{v, u};
                end
            end
        end
    end
end