function JR_save_images(filename, sol, ground_truth, modality)
% JR_save_images
%   JR_save_images(filename, sol, ground_truth, modality) saves the
% solution as an image and an error image.
%
% Input:    
%   filename [string]              
%       where to save the image and under which name
%
%   sol [matrix]              
%       image to be saved. The "optimal" image should be scaled between 0
%       and 0.8
%
%   ground_truth [matrix]              
%       the ground truth for the error image
%
%   modality [string]              
%       determines the colour map; either 'PET' or 'MRI'
%
% See also: JR_shrink JR_redwhiteblue
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% ------------------------------------------------------------------------- 

    x = JR_shrink(sol./.8, 0, 1);

    switch modality
        case 'MRI'
            imwrite(255*x, gray(256), [filename '.png'])
        case 'PET'
            imwrite(255*x, 1-gray(256), [filename '.png'])
    end

    save([filename '_results.mat'], 'sol');

    err = sol - ground_truth;
    a = .5;
    err = JR_shrink((err + a) ./ (2*a), 0, 1);
    
    imwrite(255*err, JR_redwhiteblue(256), [filename '_error.png'])
    
end