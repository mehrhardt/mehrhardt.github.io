function div = JR_diffusion(kappa, grad)
% JR_diffusion
%   div = JR_diffusion(kappa, grad) computes the divergence div(kappa grad) 
% where kappa is a scalar diffusivity and grad a gradient.
%
% Input:    
%   kappa [matrix]              
%       scalar diffusivity
%
%   grad [matrix]       
%       vector valued gradient
%
% Output:
%   div [vector]
%       divergence stored as a vector.
%
% See also: JR_gradient JR_partial_derivative_x
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
        
    div = zeros(size(grad(:,:,1)));
    div = div + JR_partial_derivative_x(grad(:,:,1) .* kappa, 'zero', 'backward');
    div = div + JR_partial_derivative_x((grad(:,:,2) .* kappa)', 'zero', 'backward')';
    div = div(:);

end