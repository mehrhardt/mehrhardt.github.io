function [x, I, s_image] = JR_images2vector(images)
% JR_images2vector
%   [x, I, s_image] = JR_images2vector(images) reshapes the input images
% as a column vector and gives the indices and size of the images so that
% this operation can be reverted.
% 
% Input:    
%   images [cell]              
%       cell array of equal size input images
%
% Output:
%   x [vector]              
%       reshaped input images as a vector
%
%   I [vector]              
%       a cell array with the indices of all images
%
%   s_image [vector]              
%       the size of the images
%
% See also: Vector2images Column
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
 
    K = length(images);
    s_image = size(images{1});
    N = prod(s_image);
    
    x = zeros(K*N, 1);
    I = cell(K,1);
    
    for k = 1 : K
        I{k} = (k-1)*N + (1:N);
        x(I{k}) = images{k}(:);
    end
    
end