function norm_3 = JR_norm3(u, beta)
%JR_norm3
%   norm_3 = JR_norm3(u, beta) computes the point-wise norm of a vector-
% valued function.
%
% Input:    
%   u [matrix]              
%       vector valued function
%
%   beta [float]              
%       parameter for smoothing of the norm
%
% Output:
%   norm_3 [matrix]
%       scalar valued function which is the norm of a vector valued 
%       function
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if nargin < 2; beta = 0; end;
    norm_3 = sqrt(sum(u.^2, 3) + beta^2);

end