function c = JR_redwhiteblue(N, middle)
% JR_redwhiteblue
%   c = JR_redwhiteblue(N, middle) creates a redwhiteblue colourmap of 
% length N where white corresponds to "middle".
% 
% Input:    
%   N [int]              
%       length of the colourmap
%
%   middle [int]              
%       position of white
%
% Output:    
%   c [matrix]              
%       output colourmap
%
% See also: JR_red JR_white JR_blue JR_colour2colour JR_merge_colours
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    if nargin < 1; N = 64; end;    
    if nargin < 2; middle = N/2; end;
       
    if middle == 0
        c = colour2colour(JR_white,JR_blue,N);
    else
        if middle == N
            c = colour2colour(JR_red,JR_white,N);
        else
            tight = 0;
            N1 = floor(middle+tight);
            N2 = ceil(N-middle);
            c = JR_merge_colours(tight,JR_colour2colour(JR_red,JR_white,N1), ...
                JR_colour2colour(JR_white,JR_blue,N2));
        end
    end
    
end