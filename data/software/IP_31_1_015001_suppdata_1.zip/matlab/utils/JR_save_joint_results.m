function JR_save_joint_results(err, conv, sol, param, parts, methods, ...
    ground_truth, filename)
% JR_save_joint_results
%   JR_save_joint_results(err, conv, sol, param, parts, methods, ground_truth, filename) 
% saves results for joint reconstruction.
%
% Input:    
%   err [vector]              
%       vector of error-values
%
%   conv [int]              
%       number of iterations until convergence; -1 if not converged
%
%   sol [cell]              
%       solution as a cell; first image is PET and second MRI
%
%   param [vector]              
%       parameters needed for the reconstruction
%
%   parts [vector]              
%       function values of the parts of the objective function at the final
%       result
%
%   methods [cell]              
%       cell of strings of labels for the parameters
%
%   ground_truth [cell]              
%       ground truth images as a cell; first image is PET and second MRI
%
%   filename [string]              
%       where to store and how to name the output
%
% See also: JR_write_stats JR_save_images
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% ------------------------------------------------------------------------- 

    filename =  JR_write_stats(filename, err, conv, param, parts, methods);

    JR_save_images([filename '_PET'], sol{1}, ground_truth{1}, 'PET');
    JR_save_images([filename '_MRI'], sol{2}, ground_truth{2}, 'MRI');

end