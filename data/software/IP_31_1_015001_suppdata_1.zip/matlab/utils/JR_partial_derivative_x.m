function partial_x = JR_partial_derivative_x(u, boundary_condition, differencing_scheme)
% JR_partial_derivative_x
%   partial_x = JR_partial_derivative_x(u, boundary_condition, differencing_scheme)
% computes the partial derivative of the scalar-valued function in the 
% first direction. Boundary conditions and how the derivative should be 
% approximated need to be specified.
%
% Input:    
%   u [matrix]              
%       scalar valued function
%
%   boundary_condition [string]              
%       either 'zero' or 'constant'
%
%   differencing_scheme [string]              
%       either 'forward', 'backward' or 'central'
%
% Output:
%   partial_x [matrix]
%       scalar valued function of partial derivatives
%
% See also: JR_extent_x JR_gradient
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------
    
    U = JR_extent_x(u, boundary_condition);

    switch differencing_scheme
        case {'forward'} % Forward differencing scheme
            partial_x = U(3:end,:) - U(2:end-1,:);
        case {'backward'} % Backward differencing scheme
            partial_x = U(2:end-1,:) - U(1:end-2,:);
        case {'central'} % Central differencing scheme
            partial_x = .5*(U(3:end,:) - U(1:end-2,:));
        otherwise
            error('Choice of differencing scheme unavailable: %s', differencing_scheme)
    end
    
end