function filename = JR_write_stats(filename, err, conv, param, parts, methods)
% JR_write_stats
%   JR_write_stats(filename, err, conv, param, parts, methods) writes some
% stats of the results as a text-file.
%
% Input:    
%   filename [string]              
%       where to store and how to name the output
%
%   err [vector]              
%       vector of error-values
%
%   conv [int]              
%       number of iterations until convergence; -1 if not converged
%
%   param [vector]              
%       parameters needed for the reconstruction
%
%   parts [vector]              
%       function values of the parts of the objective function at the final
%       result
%
%   methods [cell]              
%       cell of strings of labels for the parameters
%
% See also: JR_save_results JR_save_joint_results
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    filename = [filename '_' JR_date];
    fid = fopen([filename '.stats'], 'w');
    
    fprintf(fid,   '=== methods and parameters\n');
    
    for i = 1 : length(methods)
        mi = methods{i};
        pi = param(i);
            
        fprintf(fid, '   %-15s: %3.2e\r\n', mi, pi(1));
    end

    fprintf(fid,   '\r\n=== misc\r\n');
    fprintf(fid, '   %-15s: %s\r\n', 'when?', datestr(now, 'dd-mm-yyyy HH:MM'));
    fprintf(fid, '   %-15s:', 'error');
    fprintf(fid, ' %3.2f%%', err*100);
    fprintf(fid, '\r\n');
    fprintf(fid, '   %-15s:', 'fun parts');
    fprintf(fid, ' %3.2e', parts);
    fprintf(fid, '\r\n');
    fprintf(fid, '   %-15s: %i\r\n', 'converged?', conv);
    
    fclose(fid);
    
end