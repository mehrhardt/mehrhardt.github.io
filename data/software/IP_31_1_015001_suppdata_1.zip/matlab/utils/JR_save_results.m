function JR_save_results(err, conv, sol, param, parts, methods, ...
    ground_truth, filename, modality)
% JR_save_results
%   JR_save_results(err, conv, sol, param, parts, methods, ground_truth, filename, modality)
% saves results for a separate reconstruction.
%
% Input:    
%   err [vector]              
%       vector of error-values
%
%   conv [int]              
%       number of iterations until convergence; -1 if not converged
%
%   sol [matrix]              
%       solution as a matrix
%
%   param [vector]              
%       parameters needed for the reconstruction
%
%   parts [vector]              
%       function values of the parts of the objective function at the final
%       result
%
%   methods [cell]              
%       cell of strings of labels for the parameters
%
%   ground_truth [matrix]              
%       ground truth images as a matrix
%
%   filename [string]              
%       where to store and how to name the output
%
%   modality [string]              
%       which modality are these results for? either 'PET' or 'MRI' 
%
% See also: JR_write_stats JR_save_images
%
% 2014-08-06 --------------------------------------------------------------
% Matthias J. Ehrhardt
% CMIC, University College London, UK 
% matthias.ehrhardt.11@ucl.ac.uk
% http://www.cs.ucl.ac.uk/staff/ehrhardt/software.html
%
% -------------------------------------------------------------------------
% Copyright 2014 University College London
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
% -------------------------------------------------------------------------

    filename =  JR_write_stats(filename, err, conv, param, parts, methods);
    JR_save_images(filename, sol, ground_truth, modality)
    
end